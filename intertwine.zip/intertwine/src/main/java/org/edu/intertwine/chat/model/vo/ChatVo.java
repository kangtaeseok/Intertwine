package org.edu.intertwine.chat.model.vo;

public class ChatVo {

}
